import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pandas.plotting import autocorrelation_plot
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.seasonal import seasonal_decompose
from math import sqrt
from sklearn.metrics import mean_squared_error
from statsmodels.tsa.statespace.sarimax import SARIMAX
# from pandas import datetime

import warnings
from statsmodels.tools.sm_exceptions import ConvergenceWarning
warnings.simplefilter('ignore', ConvergenceWarning)
warnings.simplefilter('ignore', UserWarning)

# def parser(x):
#     return datetime.strptime('190'+x, '%Y-%m')

def evaluate_arima_model(X, arima_order):
    # prepare training dataset
    train_size = int(len(X) * 0.6)
    train, test = X[0:train_size], X[train_size:]
    history = [np.log(x) for x in train]
    # make predictions
    predictions = list()
    for t in range(len(test)):
        model = ARIMA(history, order=arima_order)
        model_fit = model.fit()
        yhat = model_fit.forecast()[0]
        predictions.append(np.exp(yhat))
        history.append(np.log(test[t]))
    # calculate out of sample error
    rmse = sqrt(mean_squared_error(test, predictions))
    plt.plot(test)
    plt.plot(predictions, color='red')
    plt.title(name+' '+str(arima_order))
    plt.savefig(folder+'order plots/'+str(arima_order)+'.png')
    plt.clf()
    print('Worked on: ', arima_order, ', RMSE was: ', rmse)
    return rmse

def evaluate_models(dataset, p_values, d_values, q_values):
    dataset = dataset.astype('float32')
    rmses = {}
    best_score, best_cfg = float("inf"), None
    for p in p_values:
        for d in d_values:
            for q in q_values:
                order = (p,d,q)
                try:
                    rmse = evaluate_arima_model(dataset, order)
                    rmses[order] = rmse
                    if rmse < best_score:
                        best_score, best_cfg = rmse, order
                        print('ARIMA%s RMSE=%.3f' % (order,rmse))
                except:
                    continue
    print('Best ARIMA%s RMSE=%.3f' % (best_cfg, best_score))
    print(rmses)



df = pd.read_excel('../../../manitoba-markets-crops-prices-monthly.xlsx')
dates = pd.to_datetime(df.Year*10000+df.Month*100+1,format='%Y%m%d')
df = pd.concat([df,dates], axis=1)
df = df.drop(['UOM', 'Indicator','Month','Year'], axis=1)
df = df.rename(columns={0: 'Date', 'Value':'Price'})
df.set_index('Date',inplace=True)
print(df.head())



crop_names = np.unique(df.Crop.values)

print(df.columns.values)
print(len(crop_names))
print(crop_names)
print(df)


crop_dfs = {}
for c in crop_names:
    crop_dfs[c] = df[df.Crop==c].drop(['Crop'], axis=1)

print(crop_names)

name = 'Wheat, Western Red Spring'
folder =  './'
d = crop_dfs['Wheat, Western Red Spring']
# print(d.info())s
# print(d)

duplicated_indexes = d[d.index.duplicated(keep=False)]  # Keep=False to mark all duplicates

# Display duplicated indexes (if any)
if not duplicated_indexes.empty:
    print("Duplicated Indexes:")
    print(duplicated_indexes)
else:
    print("No duplicated indexes found.")
    
from scipy.interpolate import interp1d

# Assuming 'df' is your DataFrame and 'column_name' is the column needing imputation

# Generate sample DataFrame (replace this with your actual DataFrame)

def spline_interpolate(df):

    # Convert Date column to numeric for spline interpolation
    mask_missing = df['Price'].isnull()

    # Define x and y for interpolation (non-missing values)
    x = df.loc[~mask_missing].index.astype(int).values.astype(float)  # Convert index to numeric
    y = df.loc[~mask_missing, 'Price']

    # Perform spline interpolation
    spline = interp1d(x, y, kind='cubic', fill_value='extrapolate')

    # Impute missing values using spline interpolation
    df.loc[mask_missing, 'Price'] = spline(df.loc[mask_missing].index.astype(int).values.astype(float))
    
    return df

any_missing = d.isnull().any().any()
print(any_missing)

if (any_missing):
    d = spline_interpolate(d)
    

#values form 1988 t0 1993 are missing so we drop them
# indexes = d[(d.index.year==1988) |(d.index.year==1989)|(d.index.year==1992)].index

# d = d.drop(indexes)
plt.rcParams['figure.figsize'] = [10, 10]
d['Price'].resample('M').mean().plot()
plt.title(name + ' Observation')
plt.savefig(folder+'observation.png')
plt.clf()

fig, ax = plt.subplots(figsize=(10,10))
d.groupby(pd.Grouper(level='Date', axis=0, freq='Y')).plot(ax=ax)
plt.title(name + ' Observation Segmented')
plt.savefig(folder+'observation_segmented.png')
plt.clf()

series = d.squeeze()
autocorrelation_plot(series)
plt.title(name + ' Autocorrelation')
plt.savefig(folder+'autocorrelation.png')
plt.clf()


mean_price = d.mean()
print('mean price: ', mean_price)


series.plot(kind='kde')
plt.title(name + ' Distribution')
plt.savefig(folder+'dist.png')
plt.clf()

series.apply(lambda x: np.log(x)).plot()
plt.title(name + ' Observation Log')
plt.savefig(folder+'observation_log.png')
plt.clf()

series.resample('Y').std().plot()
plt.title(name + ' STD')
plt.savefig(folder+'std.png')
plt.clf()

series.resample('Y').var().plot()
plt.title(name + ' VAR')
plt.savefig(folder+'var.png')
plt.clf()

result = seasonal_decompose(series, model='additive')
result.plot()
plt.savefig('univariate_additive.png')
plt.clf()

series.index = series.index.to_period('M')
p_values = [0,1,2,10,20]
d_values = range(0,3)
q_values = range(0,3)
evaluate_models(series.values, p_values, d_values, q_values)



# X = series.values
# size = int(len(X) * 0.6)
# train, test = X[0:size], X[size:len(X)]
# history = [x for x in train]
# predictions = list()


# for t in range(len(test)):
#     model = ARIMA(history, order=(10,1,0))
#     model_fit = model.fit()
#     output = model_fit.forecast()
#     yhat = output[0]
#     predictions.append(yhat)
#     obs = test[t]
#     history.append(obs)
#     print('predicted=%f, expected=%f' % (yhat, obs))
#     # evaluate forecasts
# rmse = sqrt(mean_squared_error(test, predictions))
# print('Test RMSE: %.3f' % rmse)
# # plot forecasts against actual outcomes
# plt.plot(test)
# plt.plot(predictions, color='red')
# plt.show()
exit(0)
# # fit model
# model = ARIMA(series, order=(132,1,0))
# model_fit = model.fit()
# # summary of fit model
# print(model_fit.summary())
# # line plot of residuals
# residuals = pd.DataFrame(model_fit.resid)
# residuals.plot()
# plt.show()
# # density plot of residuals
# residuals.plot(kind='kde')
# plt.show()
# # summary stats of residuals
# print(residuals.describe())

# series.index = series.index.to_period('M')
X = series.values
size = int(len(X) * 0.6)
train, test = X[0:size], X[size:len(X)]
history = [x for x in train]
predictions = list()


for t in range(len(test)):
    model = SARIMAX(history, order=(10,1,0),seasonal_order=(10,1,0,20))
    model_fit = model.fit()
    output = model_fit.forecast()
    yhat = output[0]
    predictions.append(yhat)
    obs = test[t]
    history.append(obs)
    print('predicted=%f, expected=%f' % (yhat, obs))
    # evaluate forecasts
rmse = sqrt(mean_squared_error(test, predictions))
print('Test RMSE: %.3f' % rmse)
# plot forecasts against actual outcomes
plt.plot(test)
plt.plot(predictions, color='red')
plt.show()

exit(0)


#######################################################################################################


name = 'Barley, #1CW'
d = crop_dfs['Barley, #1CW']
# print(d.info())
# print(d)
plt.rcParams['figure.figsize'] = [5, 5]
d['Price'].resample('M').mean().plot()
plt.savefig('trend.png')
print(type(d.index))

fig, ax = plt.subplots(figsize=(8,6))
for g in d.groupby(pd.Grouper(level='Date', axis=0, freq='Y')):
    print(g)
d.groupby(pd.Grouper(level='Date', axis=0, freq='Y')).plot(ax=ax)
plt.show()
series = d.squeeze()
autocorrelation_plot(series)
print(type(d))
plt.show()


mean_price = d.mean()
print(mean_price)
series.plot(kind='kde')
# plt.axvline(x=mean_price, color='red', linestyle='--')  # Overlay mean as a vertical line
# plt.title('Kernel Density Estimation (KDE) of Crop Prices')
# plt.xlabel('Price')
# plt.ylabel('Density')
# plt.legend()
# plt.grid(False)
plt.show()
print(series.apply(lambda x: np.log(x)))
series.apply(lambda x: np.log(x)).plot()
plt.show()
# plt.savefig('dist.png')
series.resample('Y').std().plot()
plt.show()
series.resample('Y').var().plot()
plt.show()

result = seasonal_decompose(series, model='additive')
result.plot()
plt.savefig('univariate_additive.png')
plt.clf()



series.index = series.index.to_period('M')
X = series.values
size = int(len(X) * 0.8)
train, test = X[0:size], X[size:len(X)]
history = [x for x in train]
predictions = list()


for t in range(len(test)):
    model = ARIMA(history, order=(1,1,0))
    model_fit = model.fit()
    output = model_fit.forecast()
    yhat = output[0]
    predictions.append(yhat)
    obs = test[t]
    history.append(obs)
    print('predicted=%f, expected=%f' % (yhat, obs))
    # evaluate forecasts
rmse = sqrt(mean_squared_error(test, predictions))
print('Test RMSE: %.3f' % rmse)
# plot forecasts against actual outcomes
plt.plot(test)
plt.plot(predictions, color='red')
plt.show()

# # fit model
# model = ARIMA(series, order=(132,1,0))
# model_fit = model.fit()
# # summary of fit model
# print(model_fit.summary())
# # line plot of residuals
# residuals = pd.DataFrame(model_fit.resid)
# residuals.plot()
# plt.show()
# # density plot of residuals
# residuals.plot(kind='kde')
# plt.show()
# # summary stats of residuals
# print(residuals.describe())
exit(0)


